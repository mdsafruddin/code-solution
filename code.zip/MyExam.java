//MyExam.java
import java.util.Scanner;
import java.util.Arrays;
class MyExam{
	public static void main(String args[]){
		System.out.println("Number of employees: ");
		Scanner sc = new Scanner(System.in);
		int noe = sc.nextInt();
		System.out.println();

		int goodies_price[] = new int[noe];
		String goodies_name[] = new String[noe];	
		
		for(int i=0; i<noe; i++){
			sc.nextLine();
			System.out.print("Enter the name of no "+(i+1)+" product ");  //taking the Product names from the user
			goodies_name[i] = sc.nextLine();
			
			System.out.println();
			System.out.print("Enter the price of "+goodies_name[i]+": ");  //taking the product price from the user
			goodies_price[i] = sc.nextInt();
			System.out.println();
			
		}
		
		System.out.println("The goodies selected for distribution are:");
		System.out.println();
		
		for(int i=0; i<noe; i++){
			System.out.print("\t"+goodies_name[i]+": "+goodies_price[i]);
			System.out.println();
		}
		
		Arrays.sort(goodies_price);//sorting the price
		System.out.println();
		
		int diff_of_price = goodies_price[noe-1]-goodies_price[0];
		System.out.println("And the difference between the chosen goodie with highest price and the lowest price is "+diff_of_price);
	}
}
